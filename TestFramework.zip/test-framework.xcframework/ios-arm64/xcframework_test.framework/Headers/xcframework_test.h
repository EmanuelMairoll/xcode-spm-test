#import <Foundation/Foundation.h>

//! Project version number for xcframework_test.
FOUNDATION_EXPORT double xcframework_testVersionNumber;

//! Project version string for xcframework_test.
FOUNDATION_EXPORT const unsigned char xcframework_testVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <xcframework_test/PublicHeader.h>


